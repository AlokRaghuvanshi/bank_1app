package com.fis.bankapplication.exceptions;

public class TransactionNotFound extends Exception {
	public TransactionNotFound(String message) {
		super(message);
	}
}
